package demo

func Topla(x, y int) int {
	return x + y
}

